#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[]) {
	int i;
	// Loop and display the process information.
	for(i = 0; i < 5; i++) {
		printf(1, "PID: %d Number of Context Switches: %d\n", getpid(), csinfo());
		sleep(100);
	}
	exit();
}
